import time
import functools

from loguru import logger


def metric_time(func):
    @functools.wraps(func)
    def wrapper(*args, **kwargs):
        start = time.time()
        _res = func(*args, **kwargs)
        end = time.time()
        logger.debug(f"{func.__name__}运行时间: {end-start} s")
        return _res

    return wrapper
